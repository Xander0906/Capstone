<?php

namespace App\Models;

use CodeIgniter\Database\ConnectionInterface;

class QueryModel
{

	public function __construct()
	{
		$this->db = \Config\Database::connect();
	}
	// Transaction History Admin
	function viewTransaction()
	{
		return 	$this->db->table('Schedule')
			->join('MSO', 'MSO.id = Schedule.id')
			->groupBy('Schedule.index_id')
			->orderBy('Schedule.schedule_id', 'DESC')
			->get()
			->getResult();
	}
	function viewTransactionDetails($index_id)
	{
		return 	$this->db->table('Schedule')
			->join('MSO', 'MSO.id = Schedule.id')
			->join('InspectStatus', 'InspectStatus.schedule_id = Schedule.schedule_id')
			->where('Schedule.index_id', $index_id)
			->orderBy('Schedule.schedule_id', 'DESC')
			->get()
			->getResult();
	}
	// View History in MSO
	function viewhistoryMSO($mso_id)
	{
		return 	$this->db->table('Schedule')
			->join('MSO', 'MSO.id = Schedule.id')
			->groupBy('Schedule.index_id')
			->orderBy('Schedule.schedule_id', 'DESC')
			->where('MSO.id', $mso_id)
			->get()
			->getResult();
	}
	// View History Details in MSO
	function msohistorydetails($id, $index_id)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->join('MSO', 'MSO.id = Schedule.id')
			->where('MSO.id', $id)
			->where('Schedule.index_id', $index_id)
			->get()
			->getResult();
	}
	function msohistorypayment($id, $index_id)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->join('PaymentStatus', 'PaymentStatus.inspectstatus_id = InspectStatus.inspectstatus_id')
			->join('MSO', 'MSO.id = Schedule.id')
			->where('MSO.id', $id)
			->where('Schedule.index_id', $index_id)
			->get()
			->getResult();
	}
	// schedules
	function inspectorviewsched()
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->join('MSO', 'MSO.id = Schedule.id')
			->groupBy('Schedule.index_id')
			->orderBy('Schedule.schedule_id', 'DESC')
			->where('InspectStatus.inspect_status', 'Pending')
			->get()
			->getResult();
	}
	function inspectorviewscheddetails($index_id)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->join('MSO', 'MSO.id = Schedule.id')
			->orderBy('Schedule.schedule_id', 'DESC')
			->where('Schedule.index_id', $index_id)
			->where('InspectStatus.inspect_status', 'Pending')
			->get()
			->getResult();
	}
	function treasurerviewsched()
	{
		return 	$this->db->table('PaymentStatus')
			->join('InspectStatus', 'InspectStatus.inspectstatus_id = PaymentStatus.inspectstatus_id')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->join('MSO', 'MSO.id = Schedule.id')
			->groupBy('Schedule.index_id')
			->orderBy('PaymentStatus.payment_id', 'ASC')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where('PaymentStatus.payment_status', 'Not Paid')
			->get()
			->getResult();
	}
	function treasurerviewpayment($index_id)
	{
		return 	$this->db->table('PaymentStatus')
			->join('InspectStatus', 'InspectStatus.inspectstatus_id = PaymentStatus.inspectstatus_id')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->join('MSO', 'MSO.id = Schedule.id')
			->where('Schedule.index_id', $index_id)
			->where('InspectStatus.inspect_status', 'Accepted')
			->where('PaymentStatus.payment_status', 'Not Paid')
			->orderBy('PaymentStatus.payment_id', 'ASC')
			->get()
			->getResult();
	}
	// Generate Data

	//PIG
	function week1pig($date_generate, $weeks1)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $date_generate)
			->where("InspectStatus.inspect_datetime <", $weeks1)
			->where('Schedule.animal_type', 'Pig')
			->countAllResults();
	}
	function week2pig($weeks1, $weeks2)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks1)
			->where("InspectStatus.inspect_datetime <", $weeks2)
			->where('Schedule.animal_type', 'Pig')
			->countAllResults();
	}
	function week3pig($weeks2, $weeks3)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks2)
			->where("InspectStatus.inspect_datetime <", $weeks3)
			->where('Schedule.animal_type', 'Pig')
			->countAllResults();
	}
	function week4pig($weeks3, $weeks4)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks3)
			->where("InspectStatus.inspect_datetime <", $weeks4)
			->where('Schedule.animal_type', 'Pig')
			->countAllResults();
	}
	function week5pig($weeks4, $weeks5)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks4)
			->where("InspectStatus.inspect_datetime <", $weeks5)
			->where('Schedule.animal_type', 'Pig')
			->countAllResults();
	}

	function pigstotal($date_generate, $weeks5)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $date_generate)
			->where("InspectStatus.inspect_datetime <=", $weeks5)
			->where('Schedule.animal_type', 'Pig')
			->countAllResults();
	}

	function pigcarcass($date_generate, $weeks5)
	{
		return 	$this->db->table('InspectStatus')
			->selectSum('animal_weight')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $date_generate)
			->where("InspectStatus.inspect_datetime <=", $weeks5)
			->where('Schedule.animal_type', 'Pig')
			->get()
			->getResult();
	}

	function week1cow($date_generate, $weeks1)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $date_generate)
			->where("InspectStatus.inspect_datetime <", $weeks1)
			->where('Schedule.animal_type', 'Cow')
			->countAllResults();
	}

	function week2cow($weeks1, $weeks2)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks1)
			->where("InspectStatus.inspect_datetime <", $weeks2)
			->where('Schedule.animal_type', 'Cow')
			->countAllResults();
	}

	function week3cow($weeks2, $weeks3)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks2)
			->where("InspectStatus.inspect_datetime <", $weeks3)
			->where('Schedule.animal_type', 'Cow')
			->countAllResults();
	}

	function week4cow($weeks3, $weeks4)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks3)
			->where("InspectStatus.inspect_datetime <", $weeks4)
			->where('Schedule.animal_type', 'Cow')
			->countAllResults();
	}

	function week5cow($weeks4, $weeks5)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks4)
			->where("InspectStatus.inspect_datetime <", $weeks5)
			->where('Schedule.animal_type', 'Cow')
			->countAllResults();
	}

	function cowstotal($date_generate, $weeks5)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $date_generate)
			->where("InspectStatus.inspect_datetime <=", $weeks5)
			->where('Schedule.animal_type', 'Cow')
			->countAllResults();
	}
	function cowcarcass($date_generate, $weeks5)
	{
		return 	$this->db->table('InspectStatus')
			->selectSum('animal_weight')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $date_generate)
			->where("InspectStatus.inspect_datetime <=", $weeks5)
			->where('Schedule.animal_type', 'Cow')
			->get()
			->getResult();
	}

	function week1carabao($date_generate, $weeks1)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $date_generate)
			->where("InspectStatus.inspect_datetime <", $weeks1)
			->where('Schedule.animal_type', 'Carabao')
			->countAllResults();
	}

	function week2carabao($weeks1, $weeks2)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks1)
			->where("InspectStatus.inspect_datetime <", $weeks2)
			->where('Schedule.animal_type', 'Carabao')
			->countAllResults();
	}

	function week3carabao($weeks2, $weeks3)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks2)
			->where("InspectStatus.inspect_datetime <", $weeks3)
			->where('Schedule.animal_type', 'Carabao')
			->countAllResults();
	}

	function week4carabao($weeks3, $weeks4)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks3)
			->where("InspectStatus.inspect_datetime <", $weeks4)
			->where('Schedule.animal_type', 'Carabao')
			->countAllResults();
	}

	function week5carabao($weeks4, $weeks5)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks4)
			->where("InspectStatus.inspect_datetime <", $weeks5)
			->where('Schedule.animal_type', 'Carabao')
			->countAllResults();
	}

	function carabaostotal($date_generate, $weeks5)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $date_generate)
			->where("InspectStatus.inspect_datetime <=", $weeks5)
			->where('Schedule.animal_type', 'Carabao')
			->countAllResults();
	}
	function carbaocarcass($date_generate, $weeks5)
	{
		return 	$this->db->table('InspectStatus')
			->selectSum('animal_weight')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $date_generate)
			->where("InspectStatus.inspect_datetime <=", $weeks5)
			->where('Schedule.animal_type', 'Carabao')
			->get()
			->getResult();
	}
	function week1horse($date_generate, $weeks1)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $date_generate)
			->where("InspectStatus.inspect_datetime <", $weeks1)
			->where('Schedule.animal_type', 'Horse')
			->countAllResults();
	}

	function week2horse($weeks1, $weeks2)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks1)
			->where("InspectStatus.inspect_datetime <", $weeks2)
			->where('Schedule.animal_type', 'Horse')
			->countAllResults();
	}

	function week3horse($weeks2, $weeks3)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks2)
			->where("InspectStatus.inspect_datetime <", $weeks3)
			->where('Schedule.animal_type', 'Horse')
			->countAllResults();
	}

	function week4horse($weeks3, $weeks4)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks3)
			->where("InspectStatus.inspect_datetime <", $weeks4)
			->where('Schedule.animal_type', 'Horse')
			->countAllResults();
	}

	function week5horse($weeks4, $weeks5)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks4)
			->where("InspectStatus.inspect_datetime <", $weeks5)
			->where('Schedule.animal_type', 'Horse')
			->countAllResults();
	}

	function horsestotal($date_generate, $weeks5)
	{
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $date_generate)
			->where("InspectStatus.inspect_datetime <=", $weeks5)
			->where('Schedule.animal_type', 'Horse')
			->countAllResults();
	}
	function horsecarcass($date_generate, $weeks5)
	{
		return 	$this->db->table('InspectStatus')
			->selectSum('animal_weight')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $date_generate)
			->where("InspectStatus.inspect_datetime <=", $weeks5)
			->where('Schedule.animal_type', 'Horse')
			->get()
			->getResult();
	}
	function week1others($date_generate, $weeks1)
	{
		$animals = ['Pig', 'Cow', 'Carabao', 'Horse'];
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $date_generate)
			->where("InspectStatus.inspect_datetime <", $weeks1)
			->whereNotIn('Schedule.animal_type', $animals)
			->countAllResults();
	}

	function week2others($weeks1, $weeks2)
	{
		$animals = ['Pig', 'Cow', 'Carabao', 'Horse'];
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks1)
			->where("InspectStatus.inspect_datetime <", $weeks2)
			->whereNotIn('Schedule.animal_type', $animals)
			->countAllResults();
	}

	function week3others($weeks2, $weeks3)
	{
		$animals = ['Pig', 'Cow', 'Carabao', 'Horse'];
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks2)
			->where("InspectStatus.inspect_datetime <", $weeks3)
			->whereNotIn('Schedule.animal_type', $animals)
			->countAllResults();
	}

	function week4others($weeks3, $weeks4)
	{
		$animals = ['Pig', 'Cow', 'Carabao', 'Horse'];
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks3)
			->where("InspectStatus.inspect_datetime <", $weeks4)
			->whereNotIn('Schedule.animal_type', $animals)
			->countAllResults();
	}

	function week5others($weeks4, $weeks5)
	{
		$animals = ['Pig', 'Cow', 'Carabao', 'Horse'];
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $weeks4)
			->where("InspectStatus.inspect_datetime <", $weeks5)
			->whereNotIn('Schedule.animal_type', $animals)
			->countAllResults();
	}
	function otherstotal($date_generate, $weeks5)
	{
		$animals = ['Pig', 'Cow', 'Carabao', 'Horse'];
		return 	$this->db->table('InspectStatus')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $date_generate)
			->where("InspectStatus.inspect_datetime <=", $weeks5)
			->whereNotIn('Schedule.animal_type', $animals)
			->countAllResults();
	}

	function otherscarcass($date_generate, $weeks5)
	{
		$animals = ['Pig', 'Cow', 'Carabao', 'Horse'];
		return 	$this->db->table('InspectStatus')
			->selectSum('animal_weight')
			->join('Schedule', 'Schedule.schedule_id = InspectStatus.schedule_id')
			->where('InspectStatus.inspect_status', 'Accepted')
			->where("InspectStatus.inspect_datetime >=", $date_generate)
			->where("InspectStatus.inspect_datetime <=", $weeks5)
			->whereNotIn('Schedule.animal_type', $animals)
			->get()
			->getResult();
	}
}
