<?= $this->extend('msoview/mso-navbar') ?>
<?= $this->section('content') ?>
<style>
    th {
        padding: 5px !important;
    }
</style>
<div class="card-users card">
    <div class="row px-5 table-details-sm">

        <div class="row">
            <div class="row mt-3">
                <h4 class="name-mso"><?= $firstname . ' ' . $lastname ?></h4>
            </div>
        </div>

        <div class="row mt-2 mx-2 details-sm">
            <p style="font-size:14px;">Schedule Date Time: <?php if (isset($input)) {
                                                                $input = $scheddate['Schedule_datetime'];
                                                                $date = strtotime($input);
                                                                echo date('M d, Y h:i:s a', $date);
                                                            } ?></p>

            <div class="row mt-2 table-sm-details">
                <div class="table-responsive-sm">
                    <table id="example" class="table table-striped m-auto" style="width:100%;">
                        <thead>
                            <tr>
                                <th class="px-2">Animal Type</th>
                                <th class="px-2">Quantity</th>
                                <th class="px-2">Weight</th>
                                <th class="px-2">Origin</th>
                                <th class="px-2">Status</th>
                                <th class="px-2">Reason</th>
                                <th class="px-2">Payment</th>
                                <?php if ($count > 0) : ?>
                                    <th class="px-2"></th>
                                    <th class="px-2"></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($schedules as $result) : ?>
                                <tr>
                                    <td><?= $result->Animal_type ?></td>
                                    <td><?= $result->Animal_quantity ?></td>
                                    <td><?= $result->Animal_weight ?> kg</td>
                                    <td><?= $result->Animal_origin ?></td>
                                    <td><?= $result->inspect_status ?></td>
                                    <td><?php if ($result->inspect_reason === NULL) {
                                            echo '';
                                        } else {
                                            echo $result->inspect_reason;
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php if ($result->inspect_status === 'Accepted') {
                                            foreach ($payment as $payments) :
                                                if ($result->inspectstatus_id == $payments['inspectstatus_id']) {
                                                    echo $payments['payment_status'];
                                                } else {
                                                    echo " ";
                                                }
                                            endforeach;
                                        } else {
                                            echo " ";
                                        }

                                        ?>
                                    </td>
                                    <?php if ($count > 0) : ?>
                                        <td><?php if ($result->inspect_status === 'Pending') : ?>
                                                <a class="btn-viewdetails-mso btn btn-primary btn-sm" style="color: white !important;" data-bs-toggle="modal" data-bs-target="#update<?= $result->schedule_id ?>"><i class="fa fa-edit"></i> Update</a>
                                            <?php endif; ?>
                                        </td>

                                        <!-- Modal update -->
                                        <div class="modal fade" id="update<?= $result->schedule_id ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Update Animal</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form method="post" action="<?php echo base_url(); ?>/MSOController/udpdateSched">
                                                            <input class="form-customize form-control" type="hidden" value="<?= $result->schedule_id ?>" name="scheduleID">
                                                            <input class="form-customize form-control" type="hidden" value="<?= $result->index_id ?>" name="indexID">
                                                            <div class="form-group selected" style="height:80px;">
                                                                <label>Animal Type</label>
                                                                <select class="test form-select" id="test" style="text-indent:5px;" name="animaltype" required>
                                                                    <option value="Pig" class="option option-user">&nbsp; Pig</option>
                                                                    <option value="Cow" class="option option-user">&nbsp; Cow</option>
                                                                    <option value="Carabao" class="option option-user">&nbsp; Carabao</option>
                                                                    <option value="Horse" class="option option-user">&nbsp; Horse</option>
                                                                    <option class="editable" name="editable" value="other">&nbsp; Others</option>
                                                                </select>
                                                                <input id="editOption" class="editOption form-customize form-control" placeholder="Type Custom Animal" style="display:none; background-color:white !important; width: 93% !important; position: relative !important; top: -42px !important;"></input>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Quantity</label>
                                                                <input class="form-customize form-control" value="<?= $result->Animal_quantity ?>" disabled style="text-indent:5px; !important" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Weight</label>
                                                                <input class="form-customize form-control" name="weight" value="<?= $result->Animal_weight ?>" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Origin</label>
                                                                <input class="form-customize form-control" name="origin" value="<?= $result->Animal_origin ?>" required>
                                                            </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                                                        <button type="submit" class="btn btn-primary" name="updatesched"><i class="fa fa-check"></i> Save changes</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- modal update end -->

                                        <td><?php if ($result->inspect_status === 'Pending') : ?>
                                                <a class="remove btn-viewdetails-mso btn btn-danger btn-sm" href="<?php echo base_url(); ?>/MSOController/RemoveSched/<?= $result->schedule_id ?>/<?= $result->index_id ?>" style="color: white !important;"><i class="fa fa-trash"></i> Remove</a>
                                            <?php endif; ?>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>

                    </table>
                </div>
            </div>


        </div>
    </div>
</div>

<?= $this->endSection() ?>