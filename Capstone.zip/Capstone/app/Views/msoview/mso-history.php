<?= $this->extend('msoview/mso-navbar') ?>
<?= $this->section('content') ?>
<div class="card-setsched card px-5">
  <div class="row px-3">
    <div class="table-responsive-sm mt-4">
      <table id="example" class="table table-striped m-auto" style="width:100%;">
        <thead>
          <tr>
            <th class="px-2 hide-sm">Name</th>
            <th class="px-2 hide-sm">Address</th>
            <th class="px-2 hide-sm">Contact No.</th>
            <th class="px-2 hide-sm">Username</th>
            <th class="px-2">Date</th>
            <th class="px-2"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($schedules as $result) : ?>
            <tr>
              <td class="hide-sm"><?= $result->firstname . ' ' . $result->lastname ?></td>
              <td class="hide-sm"><?= $result->address ?></td>
              <td class="hide-sm"><?= $result->contact ?></td>
              <td class="hide-sm"><?= $result->username ?></td>
              <td>
                <?php
                $input = $result->Schedule_datetime;
                $date = strtotime($input);
                echo date('M d, Y h:i:s a', $date);
                ?></td>
              <td><a href="<?php echo base_url(); ?>/MSOHistoryDetails/<?= $result->index_id ?>"><button class="btn-viewdetails-mso btn btn-primary btn-sm"><i class="view-user fa fa-info-circle" style="margin-right:4px;"></i>View Details</button></a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>

      </table>
    </div>
  </div>
</div>
<?= $this->endSection() ?>