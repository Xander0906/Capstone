<?= $this->extend('inspectorview/inspector-navbar') ?>
<?= $this->section('content') ?>

<div class="card-setsched card px-5">
    <!-- body -->
    <div class="row px-5 schedules-sm">
        <div class="row m-auto mt-4">
            <?php if ($schedules != null) { ?>
                <div class="row">
                    <div class="row mt-3">
                        <h4 class="name-mso mb-3">
                            <?php foreach ($name as $names) : ?>
                                <?php echo $names['firstname'] . ' ' . $names['lastname']; ?>
                            <?php endforeach; ?>
                    </div>
                </div>
            <?php } ?>
            <?php if ($schedules == null) { ?>
                <div class="row m-auto text-center">
                    <p>All schedules have been inspected, <a href="<?php echo base_url(); ?>/InspectorSchedule" style="color:blue !important;"> click to see
                            more schedules</a>
                    </p>
                </div>
            <?php } ?>
            <?php foreach ($schedules as $result) : ?>
                <div class="row sm-space m-auto">
                    <div class="col-md-2">
                        <label class="labelUser">Animal Type</label>
                        <input type="text" class="form-customize form-control" value="<?= $result->Animal_type ?>" readonly>
                    </div>
                    <div class="col-md-1">
                        <label class="labelUser">Quantity</label>
                        <input type="text" class="form-customize form-control" value="<?= $result->Animal_quantity ?>" readonly>
                    </div>
                    <div class="col-md-1">
                        <label class="labelUser">Weight</label>
                        <input type="text" class="form-customize form-control" value="<?= $result->Animal_weight ?> kg" readonly>
                    </div>
                    <div class="col-md-2">
                        <label class="labelUser">Origin</label>
                        <input type="text" class="form-customize form-control" value="<?= $result->Animal_origin ?>" readonly>
                    </div>
                    <div class="col-md-2">
                        <label class="labelUser">Status</label>
                        <input type="text" class="form-customize form-control" value="<?= $result->inspect_status ?>" readonly>
                    </div>
                    <div class="col-md-2 accept-reject mt-auto ">
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa fa-close"></i> Reject</button>
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Reason for Rejecting</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form method="post" action="<?php echo site_url(); ?>/RejectSched/<?= $result->index_id ?>/<?= $result->inspectstatus_id ?>/<?= $result->id ?>">
                                            <textarea rows="4" name="reason" class="form-control" required></textarea>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                                        <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i>
                                            Submit</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mt-auto accept-reject accept-sm">
                        <td><a href="<?php echo site_url(); ?>/AcceptSched/<?= $result->index_id ?>/<?= $result->inspectstatus_id ?>/<?= $result->id ?>"><button class="btn btn-primary btn-sm"><i class="fa fa-check"></i> Accept</button></a></td>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?= $this->endSection() ?>