<?= $this->extend('treasurerview/treasurer-navbar') ?>
<?= $this->section('content') ?>

<div class="card-setsched card-sched-inspector card px-5">
  <div class="row schedules-sm p-5">
    <table id="example" class="table table-striped m-auto inspecto_sched" style="width:100%;">
      <thead>
        <tr>
          <th>Name</th>
          <th class="schedule_sm">Address</th>
          <th class="schedule_sm">Contact No.</th>
          <th class="schedule_sm">Username</th>
          <th>Scheduled Date</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($schedules as $result) : ?>
          <tr>
            <td><?= $result->firstname . ' ' . $result->lastname ?></td>
            <td class="schedule_sm"><?= $result->address ?></td>
            <td class="schedule_sm"><?= $result->contact ?></td>
            <td class="schedule_sm"><?= $result->username ?></td>
            <td> <?php
                  $input = $result->Schedule_datetime;
                  $date = strtotime($input);
                  echo date('M d, Y h:i:s a', $date);
                  ?></td>
            <td class="lign-left-sm"><a href="<?php echo site_url(); ?>/TreasurerUpdateSchedule/<?= $result->index_id ?>/<?= $result->id ?>"><button class="btn-viewdetails-mso btn-sm-schedule btn btn-primary btn-sm"><i class="view-user fa fa-info-circle" style="margin-right:4px;"></i>View Details</button></a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>

    </table>
  </div>
</div>
<?= $this->endSection() ?>