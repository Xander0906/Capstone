<?= $this->extend('treasurerview/treasurer-navbar') ?>
<?= $this->section('content') ?>

<div class="card-setsched card px-5">
    <!-- body -->
    <div class="row schedules-sm px-5">
        <?php if ($schedules != null) { ?>
            <div class="row m-auto mt-4">
                <div class="row">
                    <div class="row mt-3">
                        <h4 class="name-mso mb-3">
                            <?php foreach ($name as $names) : ?>
                                <?php echo $names['firstname'] . ' ' . $names['lastname']; ?>
                            <?php endforeach; ?>
                    </div>
                </div>
            <?php } ?>
            <?php if ($schedules == null) { ?>
                <div class="row m-auto text-center">
                    <p>All schedules have been mark as paid, <a href="<?php echo base_url(); ?>/TreasurerSchedule" style="color:blue !important;"> click to see
                            more schedules</a>
                    </p>
                </div>
            <?php } ?>
            <?php foreach ($schedules as $result) : ?>
                <div class=" row sm-space m-auto">
                    <div class="col-md-2">
                        <label class="labelUser">Animal Type</label>
                        <input type="text" class="form-customize form-control" value="<?= $result->Animal_type ?>" readonly>
                    </div>
                    <div class="col-md-1">
                        <label class="labelUser">Quantity</label>
                        <input type="text" class="form-customize form-control" value="<?= $result->Animal_quantity ?>" readonly>
                    </div>
                    <div class="col-md-1">
                        <label class="labelUser">Weight</label>
                        <input type="text" class="form-customize form-control" value="<?= $result->Animal_weight ?>" readonly>
                    </div>
                    <div class="col-md-2">
                        <label class="labelUser">Origin</label>
                        <input type="text" class="form-customize form-control" value="<?= $result->Animal_origin ?>" readonly>
                    </div>
                    <div class="col-md-2">
                        <label class="labelUser">Inspected Date</label>
                        <input type="text" id="date" class="form-customize form-control" value="<?php
                                                                                                $input = $result->inspect_datetime;
                                                                                                $date = strtotime($input);
                                                                                                echo date('M d, Y h:i:s a', $date);
                                                                                                ?>" readonly>
                    </div>
                    <div class="col-md-2">
                        <label class="labelUser">Payment Status</label>
                        <input type="text" class="form-customize form-control" value="<?= $result->payment_status ?>" readonly>
                    </div>
                    <div class="col-md-2 mt-auto accept-reject accept-sm">
                        <td><a href="<?php echo site_url(); ?>/MarkASPaid/<?= $result->payment_id ?>/<?= $result->index_id ?>/<?= $result->id ?>"><button class="btn btn-primary btn-sm"><i class="fa fa-check"></i> Mark as Paid</button></a>
                        </td>
                    </div>
                </div>
            <?php endforeach; ?>
            </div>
    </div>
</div>

<?= $this->endSection() ?>