<?= $this->extend('treasurerview/treasurer-navbar') ?>
<?= $this->section('content') ?>
<div class="card-users card">

  <div class="row m-auto mt-5 mx-3">
    <div class="title-user col-md-7 m-auto mt-4">
      <h2 class="title">LIVESTOCK SLAUGHTERHOUSE</h2>
      <h2 class="title-userist title1">MANAGEMENT SYSTEM</h2>

      <p class="home-definition home-definition-users mt-3">
        A slaughterhouse, also called abattoir, is a facility where
        animals are slaughtered to
        provide foods for humans. Slaughterhouses provide an
        opportunity for inspection and evaluation of fitness
        for human consumption as it allows checking the live animals
        on
        arrival (antemortem inspection) as well as the carcases and
        other parts such as organs
        of slaughtered animals(postmortem inspection).
      </p>
      <div class="row mt-5">
        <div class="button-con">
          <a href="<?php echo base_url() ?>/TreasurerSchedule"><button class="get-started btn btn-primary">Get Started</button></a>
        </div>
      </div>
    </div>
    <div class="col-md-4 order-md-last order-first">
      <img src="assets/img/LOGO LIVESTOCK.png" alt="" height="900" class="img-fluid">
    </div>
  </div>
  <div class="row mt-5"></div>
  <div class="row mt-5"></div>
  <div class="row mt-4"></div>
  <div class="row mt-3"></div>
  <div class="row mt-0"></div>
</div>
<p class="copyright">© Copyright 2022 Department of Agriculture</p>
<?= $this->endSection() ?>