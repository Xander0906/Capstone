<?= $this->extend('adminview/admin-navbar') ?>
<?= $this->section('content') ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="card-custom card">
        <div class="row px-3">
          <div class="row header-manage mx-4">
            <h1 class="manage-header"><i class="fa fa-cog px-2"></i>View Transaction</h1>
          </div>
          <div class="table-responsive-sm mt-4">
            <table id="example" class="table table-striped m-auto" style="width:100%;">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Address</th>
                  <th>Contact No.</th>
                  <th>Username</th>
                  <th>Scheduled Date</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($transaction as $transactions) : ?>
                  <tr>
                    <td><?= $transactions->firstname . ' ' . $transactions->lastname ?></td>
                    <td><?= $transactions->address ?></td>
                    <td><?= $transactions->contact ?></td>
                    <td><?= $transactions->username ?></td>
                    <td>
                      <?php $input = $transactions->Schedule_datetime;
                      $date = strtotime($input);
                      echo date('M d, Y h:i:s a', $date);
                      ?></td>
                    <td><a href="<?php echo base_url(); ?>/TransactionDetails/<?= $transactions->index_id ?>/<?= $transactions->id ?>"><button class="btn-viewdetails-mso btn btn-primary btn-sm"><i class="view-user fa fa-info-circle"></i> View Details</button></a></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>

            </table>
          </div>

          <div class="row mt-5"></div>
          <div class="row mt-5"></div>
          <div class="row mt-5"></div>
          <div class="row mt-5"></div>
          <div class="row mt-5"></div>
        </div>
      </div>
    </div>
  </div>
  <p class="copyright">© Copyright 2022 Department of Agriculture</p>
</div>
<?= $this->endSection() ?>