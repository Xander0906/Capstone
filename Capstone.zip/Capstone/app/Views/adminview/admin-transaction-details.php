<?= $this->extend('adminview/admin-navbar') ?>
<?= $this->section('content') ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card-custom card">
                <div class="row px-5 table-details-sm">

                    <div class="row">
                        <div class="row mt-5">
                            <?php foreach ($MSO as $MSOS) : ?>
                                <h4 class="name-mso"><?php echo $MSOS['firstname'] . ' ' . $MSOS['lastname']  ?></h4>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="row mt-2 mx-2 details-sm">

                        <div class="row mt-2 table-sm-details">
                            <div class="table-responsive-sm">
                                <table id="example" class="table table-striped m-auto" style="width:100%;">
                                    <thead>
                                        <tr>
                                            <th class="px-2">Animal Type</th>
                                            <th class="px-2">Quantity</th>
                                            <th class="px-2">Weight</th>
                                            <th class="px-2">Origin</th>
                                            <th class="px-2">Status</th>
                                            <th class="px-2">Reason</th>
                                            <th class="px-2">Payment</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($transaction as $result) : ?>
                                            <tr>
                                                <td><?= $result->Animal_type ?></td>
                                                <td><?= $result->Animal_quantity ?></td>
                                                <td><?= $result->Animal_weight ?> kg</td>
                                                <td><?= $result->Animal_origin ?></td>
                                                <td><?= $result->inspect_status ?></td>
                                                <td><?php if ($result->inspect_reason === NULL) {
                                                        echo '';
                                                    } else {
                                                        echo $result->inspect_reason;
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php if ($result->inspect_status === 'Accepted') {
                                                        foreach ($payment as $payments) :
                                                            if ($result->inspectstatus_id == $payments['inspectstatus_id']) {
                                                                echo $payments['payment_status'];
                                                            } else {
                                                                echo " ";
                                                            }
                                                        endforeach;
                                                    } else {
                                                        echo " ";
                                                    }

                                                    ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>

                                </table>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>


    </div>
</div>
<?= $this->endSection() ?>