-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 05, 2023 at 06:41 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `capstone`
--

-- --------------------------------------------------------

--
-- Table structure for table `dainspector`
--

CREATE TABLE `dainspector` (
  `id` int(30) NOT NULL,
  `DAStaff_id` int(30) DEFAULT NULL,
  `firstname` varchar(30) DEFAULT NULL,
  `lastname` varchar(30) DEFAULT NULL,
  `username` varchar(40) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `status` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dainspector`
--

INSERT INTO `dainspector` (`id`, `DAStaff_id`, `firstname`, `lastname`, `username`, `password`, `contact`, `address`, `status`) VALUES
(1, 1, 'CJ Carl', 'Duting', 'CJDuting', '$2y$10$pXNf/SKdawXHxdR7ByF7ZOfsS.eYaFjOE5KZDz0KlKG/raCqgx7L2', '+639935895528', 'Manduriao, Iloilo', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dastaff`
--

CREATE TABLE `dastaff` (
  `DAStaff_id` int(30) NOT NULL,
  `DAStaff_firstname` varchar(30) DEFAULT NULL,
  `DAStaff_lastname` varchar(30) DEFAULT NULL,
  `DAStaff_username` varchar(30) DEFAULT NULL,
  `DAStaff_password` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dastaff`
--

INSERT INTO `dastaff` (`DAStaff_id`, `DAStaff_firstname`, `DAStaff_lastname`, `DAStaff_username`, `DAStaff_password`) VALUES
(1, 'Alexander', 'Novo', 'Admin', '$2y$10$Cw9rHLdPKS.z6zg9fFsDEuL4hKFU9E/uQGcSsf7bessZwW8kJarhO');

-- --------------------------------------------------------

--
-- Table structure for table `datreasurer`
--

CREATE TABLE `datreasurer` (
  `id` int(30) NOT NULL,
  `DAStaff_id` int(30) DEFAULT NULL,
  `firstname` varchar(30) DEFAULT NULL,
  `lastname` varchar(30) DEFAULT NULL,
  `username` varchar(40) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `status` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datreasurer`
--

INSERT INTO `datreasurer` (`id`, `DAStaff_id`, `firstname`, `lastname`, `username`, `password`, `contact`, `address`, `status`) VALUES
(1, 1, 'Chloyd', 'Pernia', 'ChloydPernia', '$2y$10$jKF6AsoguwrwWX5saICQteHcS5K/xtDuGPV.s3XsarMiI8l7f5MOu', '+639935895528', 'Dumarao', 1);

-- --------------------------------------------------------

--
-- Table structure for table `inspectstatus`
--

CREATE TABLE `inspectstatus` (
  `inspectstatus_id` int(250) NOT NULL,
  `Schedule_id` int(30) DEFAULT NULL,
  `id` int(30) DEFAULT NULL,
  `inspect_status` varchar(30) DEFAULT NULL,
  `inspect_reason` varchar(100) DEFAULT NULL,
  `inspect_datetime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inspectstatus`
--

INSERT INTO `inspectstatus` (`inspectstatus_id`, `Schedule_id`, `id`, `inspect_status`, `inspect_reason`, `inspect_datetime`) VALUES
(12, 12, NULL, 'Pending', '', '2022-12-18 21:34:06'),
(13, 13, NULL, 'Pending', '', '2022-12-18 21:34:06');

-- --------------------------------------------------------

--
-- Table structure for table `mso`
--

CREATE TABLE `mso` (
  `id` int(200) NOT NULL,
  `DAStaff_id` int(30) DEFAULT NULL,
  `firstname` varchar(30) DEFAULT NULL,
  `lastname` varchar(30) DEFAULT NULL,
  `username` varchar(40) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `registereddate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mso`
--

INSERT INTO `mso` (`id`, `DAStaff_id`, `firstname`, `lastname`, `username`, `password`, `contact`, `address`, `status`, `registereddate`) VALUES
(1, 1, 'Jorrine', 'Simaurio', 'JorrineSimaurio', '$2y$10$fB66DJq1r7GayZUJTHXgpO7.u2zxSN.xMfk8jd.38aiZergLrfg.C', '+639935895528', 'Cabatuan, Iloilo', 1, '2022-12-01 17:30:25'),
(2, 1, 'Leam Gomie', 'Galicia', 'LeamGalicia', '$2y$10$MvBv7WDPCODNMwUzG5/a2uYP6ufa/od8QCqZeEAmFjViKMLPWu.9.', '+639935895528', 'Dumanggas', 1, '2022-12-02 22:50:02'),
(3, 1, 'Louisse', 'Lingat', 'LouisseLingat', '$2y$10$eIoMMnGx/ZY033nxWxB5pOWTH8dLryr9T2QLNqzOBoKa3fXzss4TS', '+639298654243', 'uwuu st., brgy. bark bark, iloilo city', 1, '2022-12-05 11:56:52');

-- --------------------------------------------------------

--
-- Table structure for table `paymentstatus`
--

CREATE TABLE `paymentstatus` (
  `payment_id` int(200) NOT NULL,
  `inspectstatus_id` int(30) DEFAULT NULL,
  `id` int(30) DEFAULT NULL,
  `payment_status` varchar(30) DEFAULT NULL,
  `payment_datetime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paymentstatus`
--

INSERT INTO `paymentstatus` (`payment_id`, `inspectstatus_id`, `id`, `payment_status`, `payment_datetime`) VALUES
(1, 12, NULL, 'Not Paid', '2022-12-16 23:55:44'),
(2, 13, NULL, 'Not Paid', '2022-12-16 23:55:44');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `schedule_id` int(200) NOT NULL,
  `index_id` int(200) DEFAULT NULL,
  `id` int(30) DEFAULT NULL,
  `Animal_type` varchar(30) DEFAULT NULL,
  `Animal_quantity` varchar(60) DEFAULT NULL,
  `Animal_weight` varchar(60) DEFAULT NULL,
  `Animal_origin` varchar(60) DEFAULT NULL,
  `Schedule_datetime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`schedule_id`, `index_id`, `id`, `Animal_type`, `Animal_quantity`, `Animal_weight`, `Animal_origin`, `Schedule_datetime`) VALUES
(12, 1, 1, 'Pig', '1', '33', 'Alexander Novo', '2022-12-17 17:55:00'),
(13, 1, 1, 'Cow', '1', '45', 'Alexander Novo', '2022-12-17 17:55:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dainspector`
--
ALTER TABLE `dainspector`
  ADD PRIMARY KEY (`id`),
  ADD KEY `DAStaff_id` (`DAStaff_id`);

--
-- Indexes for table `dastaff`
--
ALTER TABLE `dastaff`
  ADD PRIMARY KEY (`DAStaff_id`);

--
-- Indexes for table `datreasurer`
--
ALTER TABLE `datreasurer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `DAStaff_id` (`DAStaff_id`);

--
-- Indexes for table `inspectstatus`
--
ALTER TABLE `inspectstatus`
  ADD PRIMARY KEY (`inspectstatus_id`),
  ADD KEY `Schedule_id` (`Schedule_id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `mso`
--
ALTER TABLE `mso`
  ADD PRIMARY KEY (`id`),
  ADD KEY `DAStaff_id` (`DAStaff_id`);

--
-- Indexes for table `paymentstatus`
--
ALTER TABLE `paymentstatus`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `inspectstatus_id` (`inspectstatus_id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`schedule_id`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dainspector`
--
ALTER TABLE `dainspector`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dastaff`
--
ALTER TABLE `dastaff`
  MODIFY `DAStaff_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `datreasurer`
--
ALTER TABLE `datreasurer`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inspectstatus`
--
ALTER TABLE `inspectstatus`
  MODIFY `inspectstatus_id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `mso`
--
ALTER TABLE `mso`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `paymentstatus`
--
ALTER TABLE `paymentstatus`
  MODIFY `payment_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `schedule_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dainspector`
--
ALTER TABLE `dainspector`
  ADD CONSTRAINT `dainspector_ibfk_1` FOREIGN KEY (`DAStaff_id`) REFERENCES `dastaff` (`DAStaff_id`);

--
-- Constraints for table `datreasurer`
--
ALTER TABLE `datreasurer`
  ADD CONSTRAINT `datreasurer_ibfk_1` FOREIGN KEY (`DAStaff_id`) REFERENCES `dastaff` (`DAStaff_id`);

--
-- Constraints for table `inspectstatus`
--
ALTER TABLE `inspectstatus`
  ADD CONSTRAINT `inspectstatus_ibfk_1` FOREIGN KEY (`Schedule_id`) REFERENCES `schedule` (`schedule_id`),
  ADD CONSTRAINT `inspectstatus_ibfk_2` FOREIGN KEY (`id`) REFERENCES `dainspector` (`id`);

--
-- Constraints for table `mso`
--
ALTER TABLE `mso`
  ADD CONSTRAINT `mso_ibfk_1` FOREIGN KEY (`DAStaff_id`) REFERENCES `dastaff` (`DAStaff_id`);

--
-- Constraints for table `paymentstatus`
--
ALTER TABLE `paymentstatus`
  ADD CONSTRAINT `paymentstatus_ibfk_1` FOREIGN KEY (`inspectstatus_id`) REFERENCES `inspectstatus` (`inspectstatus_id`),
  ADD CONSTRAINT `paymentstatus_ibfk_2` FOREIGN KEY (`id`) REFERENCES `datreasurer` (`id`);

--
-- Constraints for table `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`id`) REFERENCES `mso` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
