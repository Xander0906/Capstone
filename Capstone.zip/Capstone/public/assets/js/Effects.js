// navbar effects
staff = document.getElementById("staff");
home = document.getElementById("home");
manage = document.getElementById("manage");
transaction = document.getElementById("transaction");

$(".nav-link").click(function () {
  currentDataAttr = event.target.getAttribute("data-showName");
  window.localStorage.setItem("dataAttr", currentDataAttr);
});

$(document).ready(function () {
  currentDataAttr = window.localStorage.getItem("dataAttr");
  if (currentDataAttr === "bg-gradient-primary0") {
    staff.classList.add(currentDataAttr);
  } else if (currentDataAttr === "bg-gradient-primary1") {
    home.classList.add(currentDataAttr);
  } else if (currentDataAttr === "bg-gradient-primary2") {
    manage.classList.add(currentDataAttr);
  } else if (currentDataAttr === "bg-gradient-primary3") {
    transaction.classList.add(currentDataAttr);
  }
});

/**Logout */
$(".logout").on("click", function (e) {
  e.preventDefault();
  const href = $(this).attr("href");

  Swal.fire({
    type: "warning",
    icon: "warning",
    title: "Are You Sure?",
    text: "You will be logout",
    showCancelButton: true,
    confirmButtonColor: "#d33",
    cancelButtonColor: "#3085d6",
    confirmButtonText: "Logout",
    customClass: {
      actions: "my-actions",
      cancelButton: "order-1 right-gap",
      confirmButton: "order-2",
      container: "my-swal",
    },
  }).then((result) => {
    if (result.value) {
      document.location.href = href;
    }
  });
});

/**Logout */
$(".remove").on("click", function (e) {
  e.preventDefault();
  const href = $(this).attr("href");

  Swal.fire({
    type: "warning",
    icon: "warning",
    title: "Are You Sure?",
    text: "Animal will be remove",
    showCancelButton: true,
    confirmButtonColor: "#d33",
    cancelButtonColor: "#3085d6",
    confirmButtonText: "Remove",
    customClass: {
      actions: "my-actions",
      cancelButton: "order-1 right-gap",
      confirmButton: "order-2",
      container: "my-swal",
    },
  }).then((result) => {
    if (result.value) {
      document.location.href = href;
    }
  });
});

/**Logout */

/**Datatables */
$(document).ready(function () {
  $("#example").DataTable();
});

/**Fafa eye */
function currentpass() {
  var x = document.getElementById("currentpass");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

function newpass() {
  var x = document.getElementById("newpass");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

function password() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

function confirmpassword() {
  var x = document.getElementById("confirmpassword");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
function confirmnewpass() {
  var x = document.getElementById("confirmnewpass");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

/**Delete User */
$(".deleteuser").on("click", function (e) {
  e.preventDefault();
  const href = $(this).attr("href");

  Swal.fire({
    type: "warning",
    icon: "warning",
    title: "Are You Sure?",
    text: "User will be deleted",
    showCancelButton: true,
    confirmButtonColor: "#d33",
    cancelButtonColor: "#3085d6",
    confirmButtonText: "Delete User",
    customClass: {
      actions: "my-actions",
      cancelButton: "order-1 right-gap",
      confirmButton: "order-2",
    },
  }).then((result) => {
    if (result.value) {
      document.location.href = href;
    }
  });
});

/**Success Message */
function msg() {
  swal.fire({
    title: "Welcome" + " " + title,
    text: message,
    icon: "success",
  });
}

function success() {
  swal.fire({
    title: "Success",
    text: messagesuccess,
    icon: "success",
  });
}

function failed() {
  swal.fire({
    title: "Failed",
    text: messagefailed,
    icon: "warning",
  });
}
/**Generate Report */
function printCertificate() {
  const printContents = document.getElementById("pdf").innerHTML;
  const originalContents = document.body.innerHTML;
  document.body.innerHTML = printContents;
  window.print();
  document.body.innerHTML = originalContents;
}
$(".sm-download").on("click", function () {
  alert("Yow");
});

function CreatePDFfromHTML() {
  var yow = document.getElementById("pdf-sm");
  yow.style.display = "block";
  var HTML_Width = 297;
  var HTML_Height = 210;
  var top_left_margin = 15;
  var PDF_Width = HTML_Width + top_left_margin * 1.5;
  var PDF_Height = PDF_Width * 1.3 + top_left_margin * 1.5;
  var canvas_image_width = HTML_Width;
  var canvas_image_height = HTML_Height;

  var totalPDFPages = Math.ceil(HTML_Height / PDF_Height) - 1;

  html2canvas($("#pdf")[0]).then(function (canvas) {
    var imgData = canvas.toDataURL("image/jpeg", 1.0);
    var pdf = new jsPDF("p", "pt", [PDF_Width, PDF_Height]);
    pdf.addImage(
      imgData,
      "JPG",
      top_left_margin,
      top_left_margin,
      canvas_image_width,
      canvas_image_height
    );
    for (var i = 1; i <= totalPDFPages; i++) {
      pdf.addPage(PDF_Width, PDF_Height);
      pdf.addImage(
        imgData,
        "JPG",
        top_left_margin,
        -(PDF_Height * i) + top_left_margin * 4,
        canvas_image_width,
        canvas_image_height
      );
    }
    pdf.save("Monthly Accomplishment Report (SlaughterHouse)");
    $("#pdf").hide();
  });
}

//clone the schedule form
jQuery(function () {
  var index = 2;
  $("#add-animal").click(function () {
    var row = jQuery("#row-of-form").clone();
    jQuery(".animaltype", row).attr("id", "animaltype" + index);
    jQuery(".animaltype1", row).attr("id", "animaltype1" + index);
    jQuery(".animaltype", row).attr("id", "animals" + index);
    jQuery(".quantity", row).attr("id", "quantity" + index);
    jQuery(".weight", row).attr("id", "weight" + index);
    jQuery(".origin", row).attr("id", "origin" + index);
    jQuery(".remove", row)
      .attr("id", "remove" + index)
      .show();
    jQuery("#row-cloned").append(row);
    index++;
    //count the number of form
    $(function () {
      var set_number = function () {
        var div_len = $(".row-of-form").length - 1;
        $("#no").val(div_len);
      };
      set_number();
    });

    $("body").on("click", ".remove", function () {
      $(this).closest("#row-of-form").remove();
      var minus = $(".row-of-form").length - 1;
      $("#no").val(minus);
    });
  });
});
//Change Select to Input separately
$("body").on("change", ".test", function () {
  var $div = $(this).closest(".selected");
  var selected = $div.find("option:selected", this).attr("class");
  if (selected == "editable") {
    $div.find(".editOption").show();

    $div.find(".editOption").keyup(function () {
      var editText = $div.find(".editOption").val();
      $div.find(".editable").val(editText);
      // $div.find(".editable").html(editText);
    });
  } else {
    $div.find(".editOption").hide();
  }
});

// Validation Login
function addInvalidClass(validation, field) {
  if (validation.hasError(field)) {
    document.getElementById(field).classList.add("is-invalid");
  }
}

// $errors = array(
//   'firstname' => 'firstname',
//   'lastname' => 'lastname',
//   'contact' => 'contact',
//   'address' => 'address',
//   'password' => 'password',
//   'confirmpassword' => 'confirmpassword',
//   'username' => 'username',
// );

// <?php if (isset($validation)) :
// $errors = [
//     'firstname',
//     'lastname',
//     'contact',
//     'address',
//     'password',
//     'confirmpassword',
//     'username'
// ];
// foreach ($errors as $field => $ids) :
//     if ($validation->hasError($field)) : ?>
//         <script>
//             $('#<?php echo $ids; ?>').addClass('is-invalid');
//         </script>
// <?php
//     endif;
// endforeach;
// endif; ?>
